<script>
  if (typeof location !== 'undefined') {
    location.href = "/swagger-php/1.x/welcome.html";
  }
</script>
