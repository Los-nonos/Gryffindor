<?php

namespace LaravelDoctrine\ORM\Exceptions;

use LogicException;

class ClassNotFound extends LogicException
{
}
