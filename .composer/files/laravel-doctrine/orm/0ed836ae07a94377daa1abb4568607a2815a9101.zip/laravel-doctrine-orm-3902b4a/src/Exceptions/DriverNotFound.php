<?php

namespace LaravelDoctrine\ORM\Exceptions;

use InvalidArgumentException;

class DriverNotFound extends InvalidArgumentException
{
}
