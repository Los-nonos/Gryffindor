<?php

namespace LaravelDoctrine\ORM\Exceptions;

use LogicException;

class ExtensionNotFound extends LogicException
{
}
